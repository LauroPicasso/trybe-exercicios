# Mentoria invertida 13h - Dia 9.3

## Proposta

Realizar a construção da lógica para receber o valor de um input e, ao clicar num botão, usar esse valor para fazer uma requisição à API [viaCEP](https://viacep.com.br/). Para isso, contamos com o arquivo HTML e CSS previamente feitos.
